This source code is programmed based on the algorithm described in:

H.J. Wang, Y.H. Shao, 

Fast truncated Huber loss SVM for large scale classification

Please give credits to this paper if you use the code for your research.
